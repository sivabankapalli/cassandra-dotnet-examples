# AstraDB .NET Driver & Logging Extensions

## 🎯 Purpose
This repository provides a **.NET 8.0 client driver abstraction for AstraDB** together with **centralized logging extensions**.  
It is designed to be POCO-agnostic, testable, and extendable, following Microsoft’s recommended layered architecture.

- **Driver (`Company.Project.AstraDb.Driver`)**  
  Generic abstraction (`IAstraDbClient`) for executing read and write operations on AstraDB, with safe logging support.

- **Logging (`Company.Project.Logging`)**  
  Centralized Serilog setup with application-level enrichment and Cassandra-aware logging hooks.

---

## 📂 Repository Structure
- `src/` → library projects  
  - `Company.Project.AstraDb.Driver` – contracts, implementation stubs, logging decorator, helpers, DI extensions  
  - `Company.Project.Logging` – Serilog integration, enrichers, DI extensions  
- `tests/` → unit test projects  
  - `Company.Project.AstraDb.Driver.Tests`  
  - `Company.Project.Logging.Tests`  
  - `Company.Project.AstraDb.Driver.IntegrationTests`  
- `examples/` → sample console application showing driver + logging integration

---

## ✅ Features
- **Abstraction first**: `IAstraDbClient` interface for testability and flexibility.
- **Decorator pattern**: `LoggingAstraDbClientDecorator` adds structured logging without leaking PII/PCI values.
- **Helpers**: utilities for safe filter logging and query clause generation.
- **Serilog integration**: `AddProjectLogging()` with enrichment.
- **Extensibility**: DI extensions (`AddAstraDbDriver`, `AddProjectLogging`) following Microsoft conventions.

---

## 🚀 Getting Started

### Build
```bash
dotnet build
```

### Run Example
```bash
dotnet run --project examples/Company.Project.AstraDb.Driver.Examples
```

### Run Tests
```bash
dotnet test
```

---

## 📌 Notes
- Current implementation includes **abstractions, stubs, and logging decorators**.  
- Database read/write methods throw `NotImplementedException` until extended with real AstraDB logic.  
- Logging is designed to be safe: only schema/table names and filter keys are logged, never values.

---

## 📖 Next Steps
- Add real AstraDB SCB integration to `AstraDbCqlClient`.
- Extend logging enrichment with query trace IDs and execution context.
- Add masking helpers for sensitive values.
- Expand test coverage (unit + integration).
