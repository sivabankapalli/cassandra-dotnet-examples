# Company.Project.Logging

## 🎯 Purpose
Centralized logging setup for applications, built on **Serilog** with safe logging practices.  
Provides reusable DI extensions and enrichers, including Cassandra-aware logging hooks.

---

## 📂 Current Implementation
- **Extensions**
  - `AddProjectLogging()` → configures Serilog with app name, environment, thread ID.
- **Enrichers**
  - `CassandraLogEnricher` → stub for attaching Cassandra context (keyspace, table, queryId).
- **Tests**
  - Verify DI registration works (`ILogger<T>` is available).
  - Verify enricher attaches expected properties.

---

## ⏳ TODOs
- Add masking helper to redact sensitive values (emails, tokens, card numbers).
- Extend `CassandraLogEnricher` with real SCB query context (traceId, coordinator).
- Provide sample Serilog JSON configuration.
- Add more unit tests.

---

## 📝 Notes
- Logging is functional, enricher is a stub.  
- Sensitive values should never be logged directly.  
- Keep this README updated as features evolve.
