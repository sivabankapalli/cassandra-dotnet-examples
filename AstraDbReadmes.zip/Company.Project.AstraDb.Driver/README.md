# Company.Project.AstraDb.Driver

## 🎯 Purpose
Generic AstraDB client abstraction for .NET, built on the Secure Connect Bundle (SCB) driver.  
This package is **POCO-agnostic** — consumers provide their own models, and the driver handles persistence in a generic way.

---

## 📂 Current Implementation
- **Abstractions**
  - `IAstraDbClient` → defines `ReadAsync<T>` and `WriteAsync<T>`.
- **Implementations**
  - `AstraDbCqlClient` → stub, throws `NotImplementedException` for now.
- **Decorators**
  - `LoggingAstraDbClientDecorator` → logs keyspace/table and POCO type; never logs sensitive filter values.
- **Helpers**
  - `FilterFormatter` → `SummarizeFilterKeys()` for safe logging, `BuildWhereClause()` for future queries.
- **Extensions**
  - `AddAstraDbDriver()` → registers client + decorator with DI.

---

## ⏳ TODOs
- Implement SCB read/write operations with parameterized queries.
- Add JSON serialization/deserialization for POCOs.
- Capture query execution info (TraceId, coordinator host).
- Add decorators (caching, metrics).
- Add unit tests.

---

## 📝 Notes
- **Abstractions only** — implementation not yet complete.  
- Logging avoids leaking PII/PCI data.  
- Keep this README updated as features evolve.
