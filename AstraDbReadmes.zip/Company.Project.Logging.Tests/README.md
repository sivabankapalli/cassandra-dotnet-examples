# Company.Project.Logging.Tests

## 🎯 Purpose
Unit tests for the Logging package.

---

## 📂 Current Coverage
- `LoggingExtensionsTests` → verifies `ILogger<T>` is registered.

---

## ⏳ TODOs
- Add tests for `CassandraLogEnricher`.
- Add tests for masking helper.
- Add logging configuration tests.

---

## 📝 Notes
- Enricher logic is stubbed; test coverage will expand later.
