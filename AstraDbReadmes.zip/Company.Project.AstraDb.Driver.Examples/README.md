# Company.Project.AstraDb.Driver.Examples

## 🎯 Purpose
Console app demonstrating how to register and use the AstraDB Driver with logging.

---

## 📂 Current Example
- Registers logging via `AddProjectLogging`.
- Registers AstraDB client via `AddAstraDbDriver`.
- Calls `ReadAsync` and `WriteAsync` (stubbed, throw NotImplementedException).
- Shows safe logging of filter keys.

---

## ⏳ TODOs
- Add working example once SCB implementation is ready.
- Demonstrate JSON serialization of POCOs.
- Show Cassandra context enrichment in logs.

---

## 📝 Notes
- Output currently shows placeholder logs and "not implemented" messages.  
- Keep examples simple for easy adoption.
