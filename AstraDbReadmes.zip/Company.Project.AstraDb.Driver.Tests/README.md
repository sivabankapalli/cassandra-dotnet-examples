# Company.Project.AstraDb.Driver.Tests

## 🎯 Purpose
Unit tests for the AstraDB Driver package.

---

## 📂 Current Coverage
- `LoggingAstraDbClientDecoratorTests` → verifies decorator calls inner client and logs safe filter keys.

---

## ⏳ TODOs
- Add tests for `FilterFormatter`.
- Add tests for real SCB implementation once ready.
- Add negative tests.

---

## 📝 Notes
- Current tests cover logging decorator only.  
- Will expand when implementation progresses.
