# Company.Project.AstraDb.Driver.IntegrationTests

## 🎯 Purpose
Placeholder for future integration tests against a real AstraDB instance.

---

## 📂 Current Status
- No integration tests yet.

---

## ⏳ TODOs
- Add test AstraDB connection setup.
- Write smoke tests for `ReadAsync` and `WriteAsync`.
- Verify logging + enrichers end-to-end.

---

## 📝 Notes
- Placeholder project; will grow with real DB integration.
