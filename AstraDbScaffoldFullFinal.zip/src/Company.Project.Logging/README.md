# Company.Project.Logging

Scaffolding README with TODOs.
