using Serilog.Core;
using Serilog.Events;

namespace Company.Project.Logging.Enrichers
{
    public class CassandraLogEnricher : ILogEventEnricher
    {
        private readonly string _keyspace;
        private readonly string _table;
        private readonly string _queryId;

        public CassandraLogEnricher(string keyspace, string table, string queryId)
        {
            _keyspace = keyspace;
            _table = table;
            _queryId = queryId;
        }

        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CassandraKeyspace", _keyspace));
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CassandraTable", _table));
            logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CassandraQueryId", _queryId));
        }
    }
}
