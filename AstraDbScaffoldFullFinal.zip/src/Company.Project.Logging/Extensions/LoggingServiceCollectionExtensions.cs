using Microsoft.Extensions.DependencyInjection;
using Serilog;

namespace Company.Project.Logging.Extensions
{
    public static class LoggingServiceCollectionExtensions
    {
        public static IServiceCollection AddProjectLogging(this IServiceCollection services, string appName)
        {
            Log.Logger = new LoggerConfiguration()
                .Enrich.WithProperty("Application", appName)
                .WriteTo.Console()
                .CreateLogger();

            services.AddLogging(lb => lb.AddSerilog());
            return services;
        }
    }
}
