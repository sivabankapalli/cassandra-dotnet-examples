using Xunit;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Company.Project.Logging.Extensions;

namespace Company.Project.Logging.Tests
{
    public class LoggingExtensionsTests
    {
        [Fact]
        public void Should_Register_ILogger()
        {
            var services = new ServiceCollection();
            services.AddProjectLogging("TestApp");
            var sp = services.BuildServiceProvider();
            var logger = sp.GetService<ILogger<LoggingExtensionsTests>>();
            Assert.NotNull(logger);
        }
    }
}
