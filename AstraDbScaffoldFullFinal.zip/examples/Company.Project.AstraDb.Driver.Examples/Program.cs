using Company.Project.AstraDb.Driver.Abstractions;
using Company.Project.AstraDb.Driver.Extensions;
using Company.Project.Logging.Extensions;
using Microsoft.Extensions.DependencyInjection;

class Program
{
    static async Task Main()
    {
        var services = new ServiceCollection();
        services.AddProjectLogging("DriverExampleApp");
        services.AddAstraDbDriver();
        var sp = services.BuildServiceProvider();

        var client = sp.GetRequiredService<IAstraDbClient>();

        try
        {
            await client.ReadAsync<object>("dev_ks", "users", new Dictionary<string, object>{{"email","test@test.com"}});
        }
        catch (NotImplementedException)
        {
            Console.WriteLine("ReadAsync not implemented yet.");
        }

        try
        {
            await client.WriteAsync("dev_ks", "users", new { Email="x@y.com"});
        }
        catch (NotImplementedException)
        {
            Console.WriteLine("WriteAsync not implemented yet.");
        }
    }
}
