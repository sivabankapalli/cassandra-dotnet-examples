using System.Collections.Generic;
using System.Threading.Tasks;
using Company.Project.AstraDb.DataApi.Abstractions;
using Company.Project.AstraDb.DataApi.Decorators;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace Company.Project.AstraDb.DataApi.Tests;

/// <summary>
/// Verifies the logging decorator delegates to the inner repository and logs around calls.
/// </summary>
public class LoggingRepositoryDecoratorTests
{
    private class Dummy { }

    [Fact]
    public async Task ReadAsync_Logs_And_Delegates()
    {
        var inner = new Mock<IRepository<Dummy>>();
        inner.Setup(x => x.ReadAsync("users", It.IsAny<object?>()))
             .ReturnsAsync(new List<Dummy> { new Dummy() });

        var logger = new Mock<ILogger<LoggingRepositoryDecorator<Dummy>>>();

        var sut = new LoggingRepositoryDecorator<Dummy>(inner.Object, logger.Object);

        var result = await sut.ReadAsync("users", new { email = "a@b.com" });

        Assert.Single(result);
        inner.Verify(x => x.ReadAsync("users", It.IsAny<object?>()), Times.Once);
    }

    [Fact]
    public async Task WriteAsync_Logs_And_Delegates()
    {
        var inner = new Mock<IRepository<Dummy>>();
        inner.Setup(x => x.WriteAsync("users", It.IsAny<Dummy>()))
             .Returns(Task.CompletedTask);

        var logger = new Mock<ILogger<LoggingRepositoryDecorator<Dummy>>>();

        var sut = new LoggingRepositoryDecorator<Dummy>(inner.Object, logger.Object);

        await sut.WriteAsync("users", new Dummy());

        inner.Verify(x => x.WriteAsync("users", It.IsAny<Dummy>()), Times.Once);
    }
}
