using System.Collections.Generic;
using Company.Project.AstraDb.DataApi.Helpers;
using Xunit;

namespace Company.Project.AstraDb.DataApi.Tests;

/// <summary>
/// Verifies the filter keys-only summary logic for safe logging.
/// </summary>
public class DataApiFilterFormatterTests
{
    [Fact]
    public void Dictionary_Produces_Keys()
    {
        var keys = DataApiFilterFormatter.SummarizeFilterKeys(new Dictionary<string, object>
        {
            ["email"] = "a@b.com",
            ["name"] = "Siva"
        });

        Assert.Equal("email, name", keys);
    }

    private class Filter { public string Email { get; set; } = ""; public int Age { get; set; } }

    [Fact]
    public void Object_Produces_Keys()
    {
        var keys = DataApiFilterFormatter.SummarizeFilterKeys(new Filter { Email = "x", Age = 1 });
        Assert.Equal("Email, Age", keys);
    }

    [Fact]
    public void Null_Yields_None()
    {
        var keys = DataApiFilterFormatter.SummarizeFilterKeys(null);
        Assert.Equal("None", keys);
    }
}
