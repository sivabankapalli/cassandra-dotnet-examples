using System;
using Company.Project.AstraDb.DataApi.Abstractions;
using Company.Project.AstraDb.DataApi.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

/// <summary>
/// Minimal write example that inserts a single user document.
/// Set env: ASTRA_ENDPOINT, ASTRA_TOKEN, ASTRA_COLLECTION.
/// </summary>
public class UserDoc
{
    public string email { get; set; } = default!;
    public string name { get; set; } = default!;
    public Guid user_id { get; set; }
}

class Program
{
    static async System.Threading.Tasks.Task Main()
    {
        var endpoint = Environment.GetEnvironmentVariable("ASTRA_ENDPOINT");
        var token = Environment.GetEnvironmentVariable("ASTRA_TOKEN");
        var collection = Environment.GetEnvironmentVariable("ASTRA_COLLECTION") ?? "users";

        if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(token))
        {
            Console.WriteLine("Set ASTRA_ENDPOINT and ASTRA_TOKEN to run this example.");
            return;
        }

        var services = new ServiceCollection();
        services.AddLogging(b => b.AddSimpleConsole());
        services.AddAstraDataApi(endpoint, token);
        var sp = services.BuildServiceProvider();

        var repo = sp.GetRequiredService<IRepository<UserDoc>>();
        var doc = new UserDoc { email = "demo@example.com", name = "Demo User", user_id = Guid.NewGuid() };
        await repo.WriteAsync(collection, doc);

        Console.WriteLine("Inserted 1 document.");
    }
}
