# AstraDB .NET Data API & Logging (Internal SDK)

## 🎯 Purpose
This repository provides a **.NET 8.0 helper for Astra DB Data API** with a standardized **read/write repository abstraction**, **logging decorator**, and **safe filter helpers**.  

- **Data API (`Company.Project.AstraDb.DataApi`)**  
  Generic, POCO-agnostic repository (`IRepository<T>`) for **read & write** over Astra Data API, plus DI and logging hooks.

## 📂 Repository Structure
- `src/` → library project(s)  
- `tests/` → unit & integration tests  
- `examples/` → sample console apps demonstrating the repository  

## ✅ Features
- Abstraction First – `IRepository<T>` with read/write
- Decorator Pattern – `LoggingRepositoryDecorator<T>`
- Helpers – `DataApiFilterFormatter`, `SerializationHelper`
- DI Extensions – `AddAstraDataApi(endpoint, token)`
- Examples – minimal read/write console apps

## 🚀 Getting Started
```bash
dotnet build
dotnet test tests/Company.Project.AstraDb.DataApi.Tests
```

Run examples (set env vars first):
```bash
dotnet run --project examples/Company.Project.AstraDb.DataApi.Examples.Read
dotnet run --project examples/Company.Project.AstraDb.DataApi.Examples.Write
```

## 📌 Notes
- Current story is scaffolding only (`throw new NotImplementedException();`)
- Logging only shows collection name + filter keys

## 📖 Next Steps
- Implement DataApiClient and IRepository
- Expand integration tests
