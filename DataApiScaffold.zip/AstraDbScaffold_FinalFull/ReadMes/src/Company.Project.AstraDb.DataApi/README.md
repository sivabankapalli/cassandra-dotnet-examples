# Company.Project.AstraDb.DataApi

## 🎯 Purpose
Internal **Data API** helper for Astra DB providing:
- `IRepository<T>` (read & write only)
- Logging decorator
- DI extensions

## 📂 Contents
- Abstractions – `IDataApiClient`, `IRepository<T>`
- Implementations – `DataApiClient`, `Repository<T>`
- Decorators – `LoggingRepositoryDecorator<T>`
- Helpers – `DataApiFilterFormatter`, `SerializationHelper`
- Extensions – DI registration

## ⚙️ Installation
```csharp
services.AddAstraDataApi(endpoint, token);
```

## 🧪 Tests
- Unit tests verify logging decorator + filter formatter
- Integration tests are placeholders

## 📌 Notes
- Methods throw `NotImplementedException()` for now
- Logging safe: only keys, not values
