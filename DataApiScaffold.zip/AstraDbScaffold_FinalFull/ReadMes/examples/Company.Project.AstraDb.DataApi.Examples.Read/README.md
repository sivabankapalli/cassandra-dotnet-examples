# Company.Project.AstraDb.DataApi.Examples.Read

## 🎯 Purpose
Minimal console app showing how to **read** via `IRepository<T>` with DI + logging.

## ▶️ Run
Set env vars:
```bash
export ASTRA_ENDPOINT="..."
export ASTRA_TOKEN="..."
export ASTRA_COLLECTION="users"
```
Run:
```bash
dotnet run --project examples/Company.Project.AstraDb.DataApi.Examples.Read
```

## 📝 Notes
- Scaffold only, methods throw NotImplementedException
- Logs collection + filter keys
