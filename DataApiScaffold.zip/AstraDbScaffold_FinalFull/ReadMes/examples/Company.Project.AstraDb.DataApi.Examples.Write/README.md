# Company.Project.AstraDb.DataApi.Examples.Write

## 🎯 Purpose
Minimal console app demonstrating a **write** (insert) via `IRepository<T>`.

## ▶️ Run
Set env vars:
```bash
export ASTRA_ENDPOINT="..."
export ASTRA_TOKEN="..."
export ASTRA_COLLECTION="users"
```
Run:
```bash
dotnet run --project examples/Company.Project.AstraDb.DataApi.Examples.Write
```

## 📝 Notes
- Scaffold only, methods throw NotImplementedException
- Logs collection name and entity type
