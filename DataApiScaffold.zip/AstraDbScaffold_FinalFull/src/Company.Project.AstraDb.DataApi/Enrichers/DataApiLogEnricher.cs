using Serilog.Core;
using Serilog.Events;

namespace Company.Project.AstraDb.DataApi.Enrichers;

/// <summary>
/// Serilog enricher that attaches Data API metadata (collection, operation) to log events.
/// Consumers can opt-in via Serilog configuration; not required for decorator to function.
/// </summary>
public sealed class DataApiLogEnricher : ILogEventEnricher
{
    private readonly string _collection;
    private readonly string _operation;

    /// <summary>
    /// Creates an enricher for a specific collection/operation tuple.
    /// </summary>
    public DataApiLogEnricher(string collection, string operation)
    {
        _collection = collection;
        _operation = operation;
    }

    /// <inheritdoc />
    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("AstraCollection", _collection));
        logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("AstraOperation", _operation));
    }
}
