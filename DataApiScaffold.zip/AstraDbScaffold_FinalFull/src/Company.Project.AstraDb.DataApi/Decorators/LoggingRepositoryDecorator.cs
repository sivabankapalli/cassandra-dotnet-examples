using Company.Project.AstraDb.DataApi.Abstractions;
using Company.Project.AstraDb.DataApi.Helpers;
using Microsoft.Extensions.Logging;

namespace Company.Project.AstraDb.DataApi.Decorators;

/// <summary>
/// Logging decorator for <see cref="IRepository{T}"/> that emits structured logs around read/write.
/// Logging behavior is controlled entirely by the consumer's logging configuration.
/// </summary>
public sealed class LoggingRepositoryDecorator<T> : IRepository<T> where T : class
{
    private readonly IRepository<T> _inner;
    private readonly ILogger<LoggingRepositoryDecorator<T>> _logger;

    /// <summary>
    /// Creates a logging decorator over an existing <see cref="IRepository{T}"/>.
    /// </summary>
    public LoggingRepositoryDecorator(IRepository<T> inner, ILogger<LoggingRepositoryDecorator<T>> logger)
    {
        _inner = inner;
        _logger = logger;
    }

    /// <inheritdoc />
    public async Task WriteAsync(string collection, T entity)
    {
        _logger.LogInformation("DataAPI Write: Collection={Collection} EntityType={Type}", collection, typeof(T).Name);
        await _inner.WriteAsync(collection, entity);
        _logger.LogInformation("DataAPI Write Complete: Collection={Collection}", collection);
    }

    /// <inheritdoc />
    public async Task<IReadOnlyList<T>> ReadAsync(string collection, object? filter = null)
    {
        _logger.LogInformation("DataAPI Read: Collection={Collection} FilterKeys={Keys}",
            collection, DataApiFilterFormatter.SummarizeFilterKeys(filter));
        var result = await _inner.ReadAsync(collection, filter);
        _logger.LogInformation("DataAPI Read Complete: Collection={Collection} Count={Count}", collection, result.Count);
        return result;
    }
}
