using Company.Project.AstraDb.DataApi.Abstractions;
using DataStax.AstraDB.DataApi;

namespace Company.Project.AstraDb.DataApi.Implementations;

/// <summary>
/// Concrete Data API client that will hold the <see cref="Database"/> reference and expose collections.
/// </summary>
public sealed class DataApiClient : IDataApiClient
{
    /// <inheritdoc />
    public Database Database => throw new NotImplementedException();

    /// <summary>
    /// Creates a new client over the Astra Data API using the given endpoint and token.
    /// </summary>
    public DataApiClient(string endpoint, string token)
    {
        throw new NotImplementedException();
    }

    /// <inheritdoc />
    public Collection<T> GetCollection<T>(string collection) where T : class
    {
        throw new NotImplementedException();
    }
}
