namespace Company.Project.AstraDb.DataApi.Abstractions;

/// <summary>
/// Public repository abstraction for **read & write** operations only.
/// </summary>
public interface IRepository<T> where T : class
{
    /// <summary>
    /// Inserts a single document into the specified collection.
    /// </summary>
    Task WriteAsync(string collection, T entity)
        => throw new NotImplementedException();

    /// <summary>
    /// Reads documents from the specified collection using an optional filter object.
    /// </summary>
    Task<IReadOnlyList<T>> ReadAsync(string collection, object? filter = null)
        => throw new NotImplementedException();
}
