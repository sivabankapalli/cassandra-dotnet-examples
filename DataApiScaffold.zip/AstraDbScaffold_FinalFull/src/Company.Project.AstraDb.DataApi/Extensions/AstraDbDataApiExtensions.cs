using Company.Project.AstraDb.DataApi.Abstractions;
using Company.Project.AstraDb.DataApi.Decorators;
using Company.Project.AstraDb.DataApi.Implementations;
using Microsoft.Extensions.DependencyInjection;

namespace Company.Project.AstraDb.DataApi.Extensions;

/// <summary>
/// DI registrations for the Data API package.
/// Registers the raw repository, then decorates it with logging (Scrutor).
/// </summary>
public static class AstraDbDataApiExtensions
{
    /// <summary>
    /// Adds Astra Data API services, including a logging-decorated <see cref="IRepository{T}"/>.
    /// Actual log output depends on the consumer's logging configuration.
    /// </summary>
    public static IServiceCollection AddAstraDataApi(this IServiceCollection services, string endpoint, string token)
    {
        services.AddSingleton<IDataApiClient>(_ => new DataApiClient(endpoint, token));

        // Register the raw repository
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

        // Decorate with logging (Scrutor required)
        services.Decorate(typeof(IRepository<>), typeof(LoggingRepositoryDecorator<>));

        return services;
    }
}
