using System.Text.Json;

namespace Company.Project.AstraDb.DataApi.Helpers;

/// <summary>
/// Central JSON options to ensure consistent serialization across the package.
/// </summary>
public static class SerializationHelper
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };

    /// <summary>Serializes a value using the package defaults.</summary>
    public static string ToJson<T>(T value) => JsonSerializer.Serialize(value, Options);
}
