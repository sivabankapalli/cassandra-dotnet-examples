using System.Collections;
using System.Reflection;

namespace Company.Project.AstraDb.DataApi.Helpers;

/// <summary>
/// Produces a **keys-only** filter summary for safe logging.
/// Works with dictionaries, anonymous objects, or POCO filters.
/// </summary>
public static class DataApiFilterFormatter
{
    /// <summary>
    /// Returns a comma-separated list of top-level filter keys or "None".
    /// </summary>
    public static string SummarizeFilterKeys(object? filter)
    {
        if (filter is null) return "None";

        if (filter is IDictionary dict)
        {
            var keys = new List<string>();
            foreach (var k in dict.Keys) keys.Add(k?.ToString() ?? string.Empty);
            return keys.Count == 0 ? "None" : string.Join(", ", keys);
        }

        var props = filter.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
        return props.Length == 0 ? "None" : string.Join(", ", props.Select(p => p.Name));
    }
}
