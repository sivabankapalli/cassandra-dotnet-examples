namespace Company.Project.AstraDb.DataApi.Abstractions;

/// <summary>
/// Public repository abstraction for **read & write** operations only.
/// Write == insert (no update/delete in this user story).
/// </summary>
/// <typeparam name="T">Document CLR type.</typeparam>
public interface IRepository<T> where T : class
{
    /// <summary>
    /// Inserts a single document into the specified collection.
    /// </summary>
    Task WriteAsync(string collection, T entity);

    /// <summary>
    /// Reads documents from the specified collection using an optional filter object.
    /// The filter can be an anonymous object or a dictionary representing a Data API query.
    /// </summary>
    Task<IReadOnlyList<T>> ReadAsync(string collection, object? filter = null);
}
