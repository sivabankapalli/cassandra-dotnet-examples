using DataStax.AstraDB.DataApi;

namespace Company.Project.AstraDb.DataApi.Abstractions;

/// <summary>
/// Abstraction over the Astra DB Data API database. 
/// Provides access to the strongly-typed <see cref="Collection{T}"/> for a given collection name.
/// </summary>
public interface IDataApiClient
{
    /// <summary>
    /// The connected Astra DB <see cref="Database"/> instance.
    /// </summary>
    Database Database { get; }

    /// <summary>
    /// Resolves a typed <see cref="Collection{T}"/> for the given collection name.
    /// </summary>
    /// <typeparam name="T">Document CLR type.</typeparam>
    /// <param name="collection">Collection name.</param>
    Collection<T> GetCollection<T>(string collection) where T : class;
}
